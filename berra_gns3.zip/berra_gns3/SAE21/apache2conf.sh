#!/bin/bash

### colors ###
rougefonce='\e[0;31m'
neutre='\e[0;m'

#### purge et installation de apache ####
sudo apt-get --purge remove apache2 -y
sudo apt-get remove apache2-common -y
apt-get install apache2 -y
sudo systemctl enable apache2
clear
#### mise en place du site ####
if [ -d /var/www/html ]; then
	sudo cp /home/test/Bureau/berra_gns3/SAE21/index.html /var/www/html
fi
sudo a2dissite 000-default.conf
if [ -d /etc/apache2/sites-available ]; then
	sudo rm /etc/apache2/sites-available/000-default.conf
	sudo cp /home/test/Bureau/berra_gns3/SAE21/ANSINELLiBERRANDEYECO.conf /etc/apache2/sites-available/
fi

if [ -f /etc/hosts ]; then
	sudo rm /etc/hosts
	sudo cp /home/test/Bureau/berra_gns3/SAE21/hosts /etc/
else
	sudo cp /home/test/Bureau/berra_gns3/SAE21/hosts /etc/
fi

#### activation du site et restart apache ####
sudo a2ensite "ANSINELLiBERRANDEYECO.conf"
sudo systemctl reload apache2

#### purge et installation bind9 ####
sudo apt-get --purge remove bind9 -y
sudo apt-get install bind9 -y

### mise en place conf dns ###

if [ -d /etc/bind ]; then
	sudo rm /etc/bind/named.conf.options
	sudo cp /home/test/Bureau/berra_gns3/named.conf.options /etc/bind/
fi
if [ -f /etc/resolv.conf ]; then
	sudo rm /etc/resolv.conf
	sudo cp /home/test/Bureau/berra_gns3/resolv.conf /etc/
fi

### finish ###
systemctl start apache2
clear
echo ''
echo -e "${rougefonce} Apache2 et DNS configurer avec succes"
echo ''
